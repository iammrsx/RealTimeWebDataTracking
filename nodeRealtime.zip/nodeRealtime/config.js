module.exports = {
	host: "localhost:5000",
	dashboardEndpoint: "/dashboard"
}
